# KIG Fürthen – vollständiges Contao-Bundle

Version 1.2.11 für Contao 5.7 und PHP 8.2 oder neuer.

Dieses Paket enthält das KIG-Fürthen-Design und eine Contao-Migration für die erneute bzw. erstmalige Einrichtung der KIG-Webseite. Die Migration legt die Beispielseiten, Artikel, ein Seitenlayout, ein Nachrichtenarchiv, die News-Module, drei Beispielnachrichten und ein Kontaktformular an.

## Inhalt nach erfolgreicher Einrichtung

- Startseite mit Panorama, Begrüßung und drei aktuellen Nachrichtenkarten
- Aktuelles mit der vollständigen Contao-News-Liste
- Mitglieder
- Mitmachen
- Kontakt mit Contao-Formulargenerator
- Impressum mit deutlich markierten Platzhaltern
- Datenschutz mit Beispieltext und deutlich markierten Ergänzungsstellen
- versteckte Nachrichtenleser-Seite für die Einzelansicht der Contao-News
- austauschbares Logo und Panorama sowie drei Bilddateien in der Contao-Dateiverwaltung
- Kontrastumschaltung, Vorlesefunktion und mobile Navigation; die Schriftgrößen-Steuerung und das Suchsymbol wurden entfernt

## Sichere Einrichtung und Wiederherstellung

Die Migration prüft die KIG-Datensätze einzeln. Fehlende KIG-Seiten, Artikel, Inhaltselemente, Module, Formulare, News-Archive, Nachrichten, Layouts und Themes werden angelegt. Bereits erkannte KIG-Datensätze werden aktualisiert bzw. wiederverwendet, statt doppelt angelegt zu werden. Andere Contao-Benutzerkonten und allgemeine Contao-Einstellungen werden nicht importiert oder absichtlich verändert.

Die Migration verwendet keine separate, nicht von Contao verwaltete Markierungstabelle mehr. Sie prüft stattdessen den tatsächlich eingerichteten Zustand der KIG-Seite: Root-Seite, Layout-Zuweisung, Unterseiten, Artikel, Nachrichten, Module, Formular und Dateien. Fehler während des Laufs werden als Ausnahme weitergegeben, damit die eigentliche Ursache sichtbar wird und die gleiche fehlgeschlagene Einrichtung nicht still wiederholt wird.

Die Migration schaltet `files/kig-fuerthen` ausdrücklich öffentlich und registriert danach die Dateien unter `files/kig-fuerthen` im Contao-Dateisystem. Das CSS und JavaScript werden direkt über das Twig-Seitentemplate geladen. Das Seitenlayout erhält außerdem das Contao-Artikelmodul im Bereich `main`, damit die Seitenartikel ausgegeben werden. Bereits vorhandene Bilddateien mit denselben Dateinamen werden nicht überschrieben. Dadurch bleiben später im Backend ausgetauschte Bilder bei einem erneuten Bundle-Update erhalten. CSS und JavaScript werden dagegen mit der Paketversion aktualisiert.

## Kontaktformular und Spamschutz

Das Kontaktformular verwendet den Contao-Formulargenerator mit Pflichtfeldern, Datenschutz-Bestätigung und dem eingebauten Sicherheitsfragen-Feld. Das Formular enthält ein Contao-Captcha als Spamschutz. Ein zusätzlicher eigener Honeypot ist in dieser Version nicht implementiert.

Für den E-Mail-Versand verwendet das Formular die Administrator-E-Mail-Adresse der Root-Seite über `{{page::adminEmail}}`. Vor dem Livegang muss im Backend unter den Eigenschaften der Website-Startseite die offizielle KIG-E-Mail-Adresse eingetragen werden. Außerdem muss ein funktionierender SMTP-Mailer eingerichtet sein. Die private E-Mail-Adresse aus der Datenbanksicherung wird nicht verwendet.

## Vor dem Livegang unbedingt ergänzen

Die Beispielseiten Impressum und Datenschutz sind noch nicht rechtlich fertig. Die Platzhalter müssen mit den echten Vereins- und Verantwortlichenangaben ersetzt werden. Ebenso sind die Empfängeradresse und der SMTP-Versand für das Kontaktformular einzurichten. Die Beispielnachrichten enthalten Mustertexte.

## Installation als Composer-Artefakt im Contao Manager

Der Paketname lautet `kig-fuerthen/contao-theme-bundle`. Diese ZIP-Datei enthält eine `composer.json` direkt im Stammverzeichnis und eine feste Composer-Version (`1.2.11`). Sie ist damit als Composer-Artefakt für den ZIP-Upload im Contao Manager vorbereitet. Für diesen direkten Upload ist kein GitHub-Repository erforderlich.

Für ein späteres Update wird eine neue ZIP-Datei mit einer höheren Versionsnummer erstellt und erneut im Contao Manager hochgeladen. Alternativ kann das Paket über ein Git-Repository bezogen werden; dafür muss das Repository den Paketquelltext und einen passenden Versions-Tag enthalten.

Nach Composer-Installation und Bundle-Aktivierung führt Contao die registrierte Migration über `contao:migrate` aus. Die Einrichtung erscheint nur nach erfolgreicher Migration. Die Migration bricht nicht allein deshalb ab, weil bereits andere Contao- oder KIG-Einträge vorhanden sind; sie ergänzt erkannte fehlende KIG-Bestandteile. Das ZIP ist kein `.cto`-Theme-Export und kein vollständiges Datenbank-Backup.

## Dateien austauschen

Die Dateien befinden sich im Contao-Dateimanager unter `files/kig-fuerthen`:

- `kig-logo.jpg`
- `panorama.jpg`
- `meldung-1.jpg`
- `meldung-2.jpg`
- `meldung-3.jpg`

Logo und Panorama können dort ausgetauscht werden. Beim Ersetzen bitte dieselben Dateinamen verwenden.

## Wichtiger Hinweis zum Repository

Das verbundene GitHub-Konto hatte beim letzten Zugriff Leserechte, aber keine Schreibrechte. Deshalb konnte dieses Paket nicht automatisch in `CronkaThemes/kig_fuerthen` veröffentlicht werden. Für Updates im Contao Manager muss das Paket nach GitHub hochgeladen und mit Git-Tags veröffentlicht werden.

## Korrektur der Nachrichten-Templates in Version 1.2.9

Die beiden eigenen Nachrichten-Templates werden aus dem Bundle-Quellordner `contao/templates/twig/news` installiert. Die Migration legt sie unter ihrem Contao-Nachrichtentemplate-Namen direkt in `templates/` und `templates/kigfuerthen/` ab: `news_latest_kig.html.twig` und `news_full_kig.html.twig`. Sie werden nicht mehr in einem zusätzlichen Unterordner `news/` im Projekt- oder Theme-Templateordner abgelegt. Dadurch stimmt der Dateipfad mit den in den News-Modulen gespeicherten Template-Namen `news_latest_kig` und `news_full_kig` überein. Nach dem Update muss der Contao-Anwendungscache neu aufgebaut werden. Bereits vorhandene Dateien in den früheren Unterordnern werden nicht automatisch gelöscht.


## Korrektur des Theme-Templateordners in Version 1.2.9

Die Migration weist dem KIG-Theme jetzt den Contao-Templateordner mit dem vollständigen relativen Wert `templates/kigfuerthen` zu. Die Installationsprüfung kontrolliert diese Zuweisung ebenfalls. Damit wird das Theme bei fehlender oder falscher Ordnerzuweisung erneut korrekt eingerichtet.

## Mitgliederbereich in Version 1.2.9

Die bestehende Seite „Mitglieder“ erhält eine responsive Kartenansicht. Die Karten enthalten bewusst neutrale Platzhalter für Namen, Funktionen, Fotos und Kurzvorstellungen. Es wurden keine echten Mitgliederdaten erfunden. Die Inhalte können im vorhandenen Contao-Textinhalt der Mitgliederseite ersetzt und erweitert werden.


## Erweiterungen in Version 1.2.9

Die Hauptnavigation enthält zusätzlich „Das sind wir“. Die Migration legt die Seiten `das-sind-wir`, `ueber-uns-leichte-sprache` und `barrierefreiheit` an und verlinkt diese im Footer. Die Texte auf diesen Seiten sind neutrale Startentwürfe. Der Inhalt der verlinkten Originalseite https://kig-fuerthen.de/das-sind-wir konnte beim Erstellen nicht zuverlässig abgerufen werden; deshalb wurden keine vermeintlich originalen Aussagen oder Personendaten übernommen. Bitte den Entwurf „Das sind wir“ mit dem freigegebenen Originalinhalt abgleichen. Die Erklärung zur Barrierefreiheit ist ausdrücklich ein Entwurf und muss vor Veröffentlichung geprüft und vervollständigt werden.

Die Schriftgrößen-Steuerung und das dekorative Suchsymbol wurden aus dem Seitentemplate entfernt. Die Kontrastdarstellung wurde auf Nachrichtenliste und Nachrichtenleser erweitert: Überschriften, Datumsangaben, Teaser, Nachrichtentext, Links, Bedienelemente und Formulare erhalten im Kontrastmodus einen schwarzen Hintergrund, weiße Schrift, gelbe Links und sichtbare Tastaturfokus-Rahmen.


## Footer-Überarbeitung in Version 1.2.10

Der Footer ist auf großen Bildschirmen in drei gut lesbare Bereiche gegliedert: KIG-Logo und Kurzbeschreibung, zwei Gruppen mit Servicelinks sowie Kontaktzeichen und Motto. Auf Tablets wechselt er auf zwei Bereiche und auf schmalen Mobilgeräten auf eine kompakte, gut lesbare Anordnung. Der Footer bleibt vollständig responsive und erhält sichtbare Tastatur-Fokusmarkierungen sowie passende Kontrastfarben.


**Beschriftung im Footer:** Der Link zur Seite `ueber-uns-leichte-sprache` wird im Footer kurz und eindeutig mit „Leichte Sprache“ bezeichnet. Der Seitenpfad und der Seiteninhalt bleiben unverändert.


## Footer-Überarbeitung in Version 1.2.11

Der Footer wurde in drei klar getrennte Bereiche aufgeteilt: KIG Fürthen mit Kurzbeschreibung und Slogan, Kontakt mit Kontakt/Impressum/Datenschutz sowie Informationen mit den Links „Leichte Sprache“ und „Barrierefreiheit“. „Das sind wir“ bleibt ausschließlich in der Hauptnavigation und wird nicht doppelt im Footer aufgeführt. Auf breiten Bildschirmen erscheinen drei Spalten; auf Tablets zwei Bereiche in einer angepassten Anordnung und auf Smartphones alle Bereiche untereinander. Schriftgröße, Abstände und Tastaturfokus wurden vergrößert bzw. klarer gestaltet. Die Kontrastdarstellung umfasst auch sämtliche Footer-Links und Fokusrahmen.
