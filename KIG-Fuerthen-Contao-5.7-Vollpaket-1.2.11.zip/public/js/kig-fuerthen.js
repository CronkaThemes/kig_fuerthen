document.addEventListener("DOMContentLoaded", () => {
    const contrastButton = document.querySelector("[data-kig-contrast]");
    const readButton = document.querySelector("[data-kig-read]");
    const menuButton = document.querySelector("[data-kig-menu]");
    const navigation = document.querySelector("#kig-navigation");

    if (contrastButton) {
        contrastButton.addEventListener("click", () => {
            const active = document.body.classList.toggle("kig-high-contrast");
            contrastButton.setAttribute("aria-pressed", String(active));
        });
    }

    if (menuButton && navigation) {
        menuButton.addEventListener("click", () => {
            const active = navigation.classList.toggle("is-open");
            menuButton.setAttribute("aria-expanded", String(active));
        });
    }

    if (readButton && "speechSynthesis" in window) {
        readButton.addEventListener("click", () => {
            if (window.speechSynthesis.speaking) {
                window.speechSynthesis.cancel();
                readButton.setAttribute("aria-pressed", "false");
                return;
            }

            const main = document.querySelector("main");
            if (!main) {
                return;
            }

            const utterance = new SpeechSynthesisUtterance(main.innerText);
            utterance.lang = "de-DE";
            utterance.onend = () => readButton.setAttribute("aria-pressed", "false");
            readButton.setAttribute("aria-pressed", "true");
            window.speechSynthesis.speak(utterance);
        });
    }
});
