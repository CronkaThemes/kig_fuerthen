<?php

namespace KigFuerthen\ContaoThemeBundle;

use Symfony\Component\HttpKernel\Bundle\AbstractBundle;

class ContaoThemeBundle extends AbstractBundle
{
}
