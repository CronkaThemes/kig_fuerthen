# KIG Fürthen – Contao 5.7 – Version 1.0.2

Dieses ZIP ist ein Composer-Artefakt für den Contao Manager. Die Datei `composer.json` liegt direkt im Stamm des ZIP-Archivs und enthält die Artefakt-Version `1.0.2`.

## Installation und Aktualisierung

1. Im Contao Manager die Paketverwaltung öffnen.
2. Dieses ZIP über die Upload-Schaltfläche oder per Drag & Drop hinzufügen.
3. Die Paketänderungen prüfen und die Installation ausführen.
4. Wenn eine ältere Version desselben Pakets installiert ist, wird `1.0.2` als neuere Version angeboten.

Für spätere Updates wird die Versionsnummer in `composer.json` erhöht und ein neues ZIP mit den Paketdateien direkt im ZIP-Stamm erstellt.

## Paketinhalt

- Composer-Bundle für Contao 5.7
- Contao-Manager-Plugin
- Twig-Vorlagen für die originale Contao-Nachrichtenliste und den Nachrichtenleser
- CSS und JavaScript
- Logo, Panorama und drei Bilddateien für die Beispielmeldungen
- HTML-Vorschau und Einrichtungshinweise

## Noch nicht automatisch angelegt

Dieses Paket installiert die Bundle-Dateien und Vorlagen. Es erstellt noch keine Seitenstruktur, keine Nachrichtenarchive und keine Frontend-Module in der Datenbank. Diese Einrichtung muss im Contao-Backend vorgenommen werden. Das originale Contao-News-System wird weiterverwendet.

Das Logo und Panorama liegen als Dateien im Paket. Ihre Auswahl als austauschbare Backend-Felder ist noch nicht als eigene Backend-Verwaltung umgesetzt.

## Technische Angaben

- Zielversion: Contao 5.7
- PHP-Anforderung: ^8.2
- Paketname: `kig-fuerthen/contao-theme-bundle`
- Paketversion: `1.0.2`
- Pakettyp: `contao-bundle`
