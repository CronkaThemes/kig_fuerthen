document.addEventListener("DOMContentLoaded", () => {
    const contrastButton = document.querySelector("[data-kig-contrast]");
    const readButton = document.querySelector("[data-kig-read]");
    const fontButtons = document.querySelectorAll("[data-kig-font]");

    if (contrastButton) {
        contrastButton.addEventListener("click", () => {
            const active = document.body.classList.toggle("kig-high-contrast");
            contrastButton.setAttribute("aria-pressed", String(active));
        });
    }

    fontButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const current = Number.parseFloat(getComputedStyle(document.documentElement).fontSize);
            const mode = button.dataset.kigFont;
            const next = mode === "normal" ? 16 : Math.min(22, Math.max(13, current + (mode === "up" ? 1 : -1)));
            document.documentElement.style.fontSize = `${next}px`;
        });
    });

    if (readButton && "speechSynthesis" in window) {
        readButton.addEventListener("click", () => {
            if (window.speechSynthesis.speaking) {
                window.speechSynthesis.cancel();
                readButton.setAttribute("aria-pressed", "false");
                return;
            }

            const main = document.querySelector("main");
            if (!main) {
                return;
            }

            const utterance = new SpeechSynthesisUtterance(main.innerText);
            utterance.lang = "de-DE";
            utterance.onend = () => readButton.setAttribute("aria-pressed", "false");
            readButton.setAttribute("aria-pressed", "true");
            window.speechSynthesis.speak(utterance);
        });
    }
});
