# KIG Fürthen – vollständiges Contao-Bundle

Version 1.1.0 für Contao 5.7 und PHP 8.2 oder neuer.

Dieses Paket enthält das KIG-Fürthen-Design und eine Contao-Migration für eine leere Contao-5.7-Installation. Die Migration legt die Beispielseiten, Artikel, ein Seitenlayout, ein Nachrichtenarchiv, die News-Module, drei Beispielnachrichten und ein Kontaktformular an.

## Inhalt nach erfolgreicher Einrichtung

- Startseite mit Panorama, Begrüßung und drei aktuellen Nachrichtenkarten
- Aktuelles mit der vollständigen Contao-News-Liste
- Mitglieder
- Mitmachen
- Kontakt mit Contao-Formulargenerator
- Impressum mit deutlich markierten Platzhaltern
- Datenschutz mit Beispieltext und deutlich markierten Ergänzungsstellen
- versteckte Nachrichtenleser-Seite für die Einzelansicht der Contao-News
- austauschbares Logo und Panorama sowie drei Bilddateien in der Contao-Dateiverwaltung
- Schriftgrößen-Anpassung, Kontrastumschaltung, Vorlesefunktion und mobile Navigation

## Sichere Ersteinrichtung

Die Migration führt die Beispiel-Einrichtung nur aus, wenn keine Seiten außer einem leeren Root-Seiteneintrag und keine Artikel, Inhaltselemente, News, Archive, Module, Formulare, Layouts oder Themes vorhanden sind. Vorhandene Webseiten-Inhalte werden nicht überschrieben. Zugangsdaten und Benutzerkonten werden nicht importiert.

Die Migration registriert die Dateien unter `files/kig-fuerthen` im Contao-Dateisystem. Bereits vorhandene Dateien mit denselben Dateinamen werden nicht überschrieben. Dadurch bleiben später im Backend ausgetauschte Bilder bei einem erneuten Bundle-Update erhalten.

## Kontaktformular und Spamschutz

Das Kontaktformular verwendet den Contao-Formulargenerator mit Pflichtfeldern, Datenschutz-Bestätigung und dem eingebauten Sicherheitsfragen-Feld. Contao setzt dabei zusätzlich ein verstecktes Honeypot-Feld ein.

Für den E-Mail-Versand verwendet das Formular die Administrator-E-Mail-Adresse der Root-Seite über `{{page::adminEmail}}`. Vor dem Livegang muss im Backend unter den Eigenschaften der Website-Startseite die offizielle KIG-E-Mail-Adresse eingetragen werden. Außerdem muss ein funktionierender SMTP-Mailer eingerichtet sein. Die private E-Mail-Adresse aus der Datenbanksicherung wird nicht verwendet.

## Vor dem Livegang unbedingt ergänzen

Die Beispielseiten Impressum und Datenschutz sind noch nicht rechtlich fertig. Die Platzhalter müssen mit den echten Vereins- und Verantwortlichenangaben ersetzt werden. Ebenso sind die Empfängeradresse und der SMTP-Versand für das Kontaktformular einzurichten. Die Beispielnachrichten enthalten Mustertexte.

## Installation als Composer-Paket

Das Repository muss als Composer-VCS-Quelle eingerichtet und mit einem Git-Tag `1.1.0` veröffentlicht werden. Der Paketname lautet `kig-fuerthen/contao-theme-bundle`. Das ZIP ist ein vollständiges Quellpaket, aber kein `.cto`-Theme-Export und kann nicht als Datenbank-Backup importiert werden.

Nach Composer-Installation und Bundle-Aktivierung führt Contao die registrierte Migration über `contao:migrate` aus. Die Einrichtung erscheint nur nach erfolgreicher Migration. Wenn die Datenbank nicht leer ist, bricht die Migration mit einer Meldung ab, ohne vorhandene Inhalte zu ändern.

## Dateien austauschen

Die Dateien befinden sich im Contao-Dateimanager unter `files/kig-fuerthen`:

- `kig-logo.jpg`
- `panorama.jpg`
- `meldung-1.jpg`
- `meldung-2.jpg`
- `meldung-3.jpg`

Logo und Panorama können dort ausgetauscht werden. Beim Ersetzen bitte dieselben Dateinamen verwenden.

## Wichtiger Hinweis zum Repository

Das verbundene GitHub-Konto hatte beim letzten Zugriff Leserechte, aber keine Schreibrechte. Deshalb konnte dieses Paket nicht automatisch in `CronkaThemes/kig_fuerthen` veröffentlicht werden. Für Updates im Contao Manager muss das Paket nach GitHub hochgeladen und mit Git-Tags veröffentlicht werden.
