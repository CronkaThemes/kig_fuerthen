# KIG Fürthen – vollständiges Contao-Bundle

Version 1.2.2 für Contao 5.7 und PHP 8.2 oder neuer.

Dieses Paket enthält das KIG-Fürthen-Design und eine Contao-Migration für die erneute bzw. erstmalige Einrichtung der KIG-Webseite. Die Migration legt die Beispielseiten, Artikel, ein Seitenlayout, ein Nachrichtenarchiv, die News-Module, drei Beispielnachrichten und ein Kontaktformular an.

## Inhalt nach erfolgreicher Einrichtung

- Startseite mit Panorama, Begrüßung und drei aktuellen Nachrichtenkarten
- Aktuelles mit der vollständigen Contao-News-Liste
- Mitglieder
- Mitmachen
- Kontakt mit Contao-Formulargenerator
- Impressum mit deutlich markierten Platzhaltern
- Datenschutz mit Beispieltext und deutlich markierten Ergänzungsstellen
- versteckte Nachrichtenleser-Seite für die Einzelansicht der Contao-News
- austauschbares Logo und Panorama sowie drei Bilddateien in der Contao-Dateiverwaltung
- Schriftgrößen-Anpassung, Kontrastumschaltung, Vorlesefunktion und mobile Navigation

## Sichere Einrichtung und Wiederherstellung

Die Migration prüft die KIG-Datensätze einzeln. Fehlende KIG-Seiten, Artikel, Inhaltselemente, Module, Formulare, News-Archive, Nachrichten, Layouts und Themes werden angelegt. Bereits erkannte KIG-Datensätze werden aktualisiert bzw. wiederverwendet, statt doppelt angelegt zu werden. Andere Contao-Benutzerkonten und allgemeine Contao-Einstellungen werden nicht importiert oder absichtlich verändert.

Die Installationskennung verwendet eine feste ID. Version 1.2.2 behebt den SQL-Fehler, bei dem beim Speichern der Installationskennung das Pflichtfeld `id` ohne Wert eingefügt wurde.

Die Migration registriert die Dateien unter `files/kig-fuerthen` im Contao-Dateisystem. Bereits vorhandene Dateien mit denselben Dateinamen werden nicht überschrieben. Dadurch bleiben später im Backend ausgetauschte Bilder bei einem erneuten Bundle-Update erhalten.

## Kontaktformular und Spamschutz

Das Kontaktformular verwendet den Contao-Formulargenerator mit Pflichtfeldern, Datenschutz-Bestätigung und dem eingebauten Sicherheitsfragen-Feld. Das Formular enthält ein Contao-Captcha als Spamschutz. Ein zusätzlicher eigener Honeypot ist in dieser Version nicht implementiert.

Für den E-Mail-Versand verwendet das Formular die Administrator-E-Mail-Adresse der Root-Seite über `{{page::adminEmail}}`. Vor dem Livegang muss im Backend unter den Eigenschaften der Website-Startseite die offizielle KIG-E-Mail-Adresse eingetragen werden. Außerdem muss ein funktionierender SMTP-Mailer eingerichtet sein. Die private E-Mail-Adresse aus der Datenbanksicherung wird nicht verwendet.

## Vor dem Livegang unbedingt ergänzen

Die Beispielseiten Impressum und Datenschutz sind noch nicht rechtlich fertig. Die Platzhalter müssen mit den echten Vereins- und Verantwortlichenangaben ersetzt werden. Ebenso sind die Empfängeradresse und der SMTP-Versand für das Kontaktformular einzurichten. Die Beispielnachrichten enthalten Mustertexte.

## Installation als Composer-Artefakt im Contao Manager

Der Paketname lautet `kig-fuerthen/contao-theme-bundle`. Diese ZIP-Datei enthält eine `composer.json` direkt im Stammverzeichnis und eine feste Composer-Version (`1.2.2`). Sie ist damit als Composer-Artefakt für den ZIP-Upload im Contao Manager vorbereitet. Für diesen direkten Upload ist kein GitHub-Repository erforderlich.

Für ein späteres Update wird eine neue ZIP-Datei mit einer höheren Versionsnummer erstellt und erneut im Contao Manager hochgeladen. Alternativ kann das Paket über ein Git-Repository bezogen werden; dafür muss das Repository den Paketquelltext und einen passenden Versions-Tag enthalten.

Nach Composer-Installation und Bundle-Aktivierung führt Contao die registrierte Migration über `contao:migrate` aus. Die Einrichtung erscheint nur nach erfolgreicher Migration. Die Migration bricht nicht allein deshalb ab, weil bereits andere Contao- oder KIG-Einträge vorhanden sind; sie ergänzt erkannte fehlende KIG-Bestandteile. Das ZIP ist kein `.cto`-Theme-Export und kein vollständiges Datenbank-Backup.

## Dateien austauschen

Die Dateien befinden sich im Contao-Dateimanager unter `files/kig-fuerthen`:

- `kig-logo.jpg`
- `panorama.jpg`
- `meldung-1.jpg`
- `meldung-2.jpg`
- `meldung-3.jpg`

Logo und Panorama können dort ausgetauscht werden. Beim Ersetzen bitte dieselben Dateinamen verwenden.

## Wichtiger Hinweis zum Repository

Das verbundene GitHub-Konto hatte beim letzten Zugriff Leserechte, aber keine Schreibrechte. Deshalb konnte dieses Paket nicht automatisch in `CronkaThemes/kig_fuerthen` veröffentlicht werden. Für Updates im Contao Manager muss das Paket nach GitHub hochgeladen und mit Git-Tags veröffentlicht werden.
