<?php

declare(strict_types=1);

namespace KigFuerthen\ContaoThemeBundle\Migration;

use Contao\CoreBundle\Migration\MigrationInterface;
use Contao\CoreBundle\Migration\MigrationResult;
use Contao\Dbafs;
use Contao\FilesModel;
use Doctrine\DBAL\Connection;
use Symfony\Component\HttpKernel\KernelInterface;

final class InstallKigSiteMigration implements MigrationInterface
{
    private const VERSION = '1.2.2';
    private const MARKER_TABLE = 'tl_kig_installation';
    private const ROOT_TITLE = 'KIG Fürthen';
    private const THEME_NAME = 'KIG Fürthen';
    private const LAYOUT_NAME = 'KIG Fürthen – Hauptlayout';
    private const ARCHIVE_TITLE = 'KIG Fürthen – Aktuelles';

    public function __construct(
        private readonly Connection $connection,
        private readonly KernelInterface $kernel,
    ) {
    }

    public function getName(): string
    {
        return self::class;
    }

    public function shouldRun(): bool
    {
        $tables = $this->connection->createSchemaManager()->listTableNames();
        $required = ['tl_page', 'tl_article', 'tl_content', 'tl_news', 'tl_news_archive', 'tl_module', 'tl_form', 'tl_form_field', 'tl_layout', 'tl_theme', 'tl_files'];

        foreach ($required as $table) {
            if (!in_array($table, $tables, true)) {
                return false;
            }
        }

        if (!$this->connection->createSchemaManager()->tablesExist([self::MARKER_TABLE])) {
            return true;
        }

        $version = $this->connection->fetchOne(
            'SELECT version FROM '.$this->connection->quoteIdentifier(self::MARKER_TABLE).' WHERE id = 1'
        );

        return self::VERSION !== $version;
    }

    public function run(): MigrationResult
    {
        try {
            $this->connection->executeStatement(
                'CREATE TABLE IF NOT EXISTS '.$this->connection->quoteIdentifier(self::MARKER_TABLE).' (id SMALLINT UNSIGNED NOT NULL PRIMARY KEY, version VARCHAR(32) NOT NULL, installed_at INT UNSIGNED NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );

            $this->installAssets();
            $this->installTemplates();

            $this->connection->beginTransaction();

            try {
                $themeId = $this->ensureTheme();
                $layoutId = $this->ensureLayout($themeId);
                $rootId = $this->ensureRootPage($layoutId);
                $pages = $this->ensurePages($rootId, $layoutId);
                $authorId = (int) ($this->connection->fetchOne('SELECT id FROM tl_user ORDER BY id LIMIT 1') ?: 0);
                $archiveId = $this->ensureNewsArchive($pages['meldung']);
                $readerModuleId = $this->ensureNewsReaderModule($themeId, $archiveId);
                $homeNewsModuleId = $this->ensureNewsListModule($themeId, $archiveId, $readerModuleId, 'KIG-Nachrichten auf der Startseite', 3);
                $newsPageModuleId = $this->ensureNewsListModule($themeId, $archiveId, $readerModuleId, 'Alle KIG-Nachrichten', 20);
                $contactFormId = $this->ensureContactForm();
                $articles = $this->ensureArticles($pages, $authorId, $homeNewsModuleId, $newsPageModuleId, $readerModuleId, $contactFormId);
                $this->ensureNews($archiveId, $authorId);
                $this->ensureRootLayout($rootId, $layoutId);

                $this->upsert(self::MARKER_TABLE, ['id' => 1], [
                    'id' => 1,
                    'version' => self::VERSION,
                    'installed_at' => time(),
                ]);

                $this->connection->commit();

                return new MigrationResult(
                    true,
                    'Die KIG-Fürthen-Seite wurde neu aufgebaut bzw. vervollständigt. Seiten, Artikel, Contao-News, News-Module, Kontaktformular, Layout, Twig-Vorlagen und Dateien wurden geprüft und fehlende Bestandteile angelegt.'
                );
            } catch (\Throwable $exception) {
                if ($this->connection->isTransactionActive()) {
                    $this->connection->rollBack();
                }

                throw $exception;
            }
        } catch (\Throwable $exception) {
            return new MigrationResult(false, 'Die KIG-Einrichtung ist fehlgeschlagen: '.$exception->getMessage());
        }
    }

    private function installAssets(): void
    {
        $source = dirname(__DIR__, 2).'/public';
        $target = $this->kernel->getProjectDir().'/files/kig-fuerthen';

        $this->ensureDirectory($target);

        $assets = [
            'images/kig-logo.jpg' => false,
            'images/panorama.jpg' => false,
            'images/meldung-1.jpg' => false,
            'images/meldung-2.jpg' => false,
            'images/meldung-3.jpg' => false,
            'css/kig-fuerthen.css' => true,
            'js/kig-fuerthen.js' => true,
        ];

        foreach ($assets as $relative => $replace) {
            $sourceFile = $source.'/'.$relative;
            $targetFile = $target.'/'.basename($relative);

            if (!is_file($sourceFile)) {
                throw new \RuntimeException('Die Paketdatei fehlt: '.$relative);
            }

            if (!$replace && is_file($targetFile)) {
                continue;
            }

            $this->copyFile($sourceFile, $targetFile);
        }

        Dbafs::addResource('files/kig-fuerthen');
    }

    private function installTemplates(): void
    {
        $source = dirname(__DIR__, 2).'/contao/templates/twig';
        $projectTemplates = $this->kernel->getProjectDir().'/templates';
        $themeTemplates = $projectTemplates.'/kigfuerthen';

        $templateFiles = [
            'fe_page_kig.html.twig' => 'fe_page_kig.html.twig',
            'news/news_latest_kig.html.twig' => 'news/news_latest_kig.html.twig',
            'news/news_full_kig.html.twig' => 'news/news_full_kig.html.twig',
        ];

        foreach ($templateFiles as $relative => $destination) {
            $sourceFile = $source.'/'.$relative;
            if (!is_file($sourceFile)) {
                throw new \RuntimeException('Die Twig-Vorlage fehlt im Paket: '.$relative);
            }

            $globalTarget = $projectTemplates.'/'.$destination;
            $themeTarget = $themeTemplates.'/'.$destination;

            $this->ensureDirectory(dirname($globalTarget));
            $this->ensureDirectory(dirname($themeTarget));
            $this->copyFile($sourceFile, $globalTarget);
            $this->copyFile($sourceFile, $themeTarget);
        }
    }

    private function ensureDirectory(string $path): void
    {
        if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
            throw new \RuntimeException('Der Ordner konnte nicht angelegt werden: '.$path);
        }
    }

    private function copyFile(string $source, string $target): void
    {
        if (!is_file($target) || !hash_equals((string) hash_file('sha256', $source), (string) hash_file('sha256', $target))) {
            if (!copy($source, $target)) {
                throw new \RuntimeException('Die Datei konnte nicht kopiert werden: '.basename($target));
            }
        }
    }

    private function ensureTheme(): int
    {
        return $this->upsert('tl_theme', ['name' => self::THEME_NAME], [
            'tstamp' => time(),
            'name' => self::THEME_NAME,
            'author' => 'KIG Fürthen',
            'folders' => serialize(['files/kig-fuerthen']),
            'templates' => 'kigfuerthen',
        ]);
    }

    private function ensureLayout(int $themeId): int
    {
        return $this->upsert('tl_layout', ['pid' => $themeId, 'name' => self::LAYOUT_NAME], [
            'pid' => $themeId,
            'tstamp' => time(),
            'name' => self::LAYOUT_NAME,
            'type' => 'default',
            'rows' => '1rw',
            'cols' => '1cl',
            'sections' => serialize([]),
            'framework' => serialize([]),
            'external' => serialize([]),
            'modules' => serialize([]),
            'template' => 'fe_page_kig',
            'combineScripts' => 1,
            'minifyMarkup' => 0,
            'viewport' => 'width=device-width,initial-scale=1.0',
            'titleTag' => '{{page::pageTitle}} - KIG Fürthen',
            'cssClass' => 'kig-layout',
            'externalJs' => serialize([]),
        ]);
    }

    private function ensureRootPage(int $layoutId): int
    {
        $rootId = $this->findId('tl_page', ['type' => 'root', 'title' => self::ROOT_TITLE]);

        if (null === $rootId) {
            $rootId = $this->connection->fetchOne("SELECT id FROM tl_page WHERE type = 'root' ORDER BY id LIMIT 1");
            $rootId = false === $rootId ? null : (int) $rootId;
        }

        $data = [
            'tstamp' => time(),
            'title' => self::ROOT_TITLE,
            'pageTitle' => self::ROOT_TITLE,
            'type' => 'root',
            'fallback' => 1,
            'published' => 1,
            'language' => 'de',
            'layout' => $layoutId,
            'enableCanonical' => 1,
            'dateFormat' => 'd.m.Y',
            'timeFormat' => 'H:i',
            'datimFormat' => 'd.m.Y H:i',
            'description' => 'Kommunale Interessen Gemeinschaft Fürthen',
        ];

        if (null === $rootId) {
            $data['pid'] = 0;
            $data['sorting'] = 128;
            return $this->insert('tl_page', $data);
        }

        $this->updateById('tl_page', $rootId, $data);

        return $rootId;
    }

    private function ensurePages(int $rootId, int $layoutId): array
    {
        $definitions = [
            'startseite' => ['title' => 'Startseite', 'alias' => 'index', 'description' => 'Herzlich willkommen bei der KIG Fürthen.'],
            'aktuelles' => ['title' => 'Aktuelles', 'alias' => 'aktuelles', 'description' => 'Neuigkeiten und Informationen aus der KIG Fürthen.'],
            'mitglieder' => ['title' => 'Mitglieder', 'alias' => 'mitglieder', 'description' => 'Informationen über die Mitglieder der KIG Fürthen.'],
            'mitmachen' => ['title' => 'Mitmachen', 'alias' => 'mitmachen', 'description' => 'So können Sie sich in Fürthen einbringen.'],
            'kontakt' => ['title' => 'Kontakt', 'alias' => 'kontakt', 'description' => 'Kontakt zur KIG Fürthen.'],
            'impressum' => ['title' => 'Impressum', 'alias' => 'impressum', 'description' => 'Impressum der KIG Fürthen.'],
            'datenschutz' => ['title' => 'Datenschutz', 'alias' => 'datenschutz', 'description' => 'Datenschutzhinweise der KIG Fürthen.'],
            'meldung' => ['title' => 'Nachricht', 'alias' => 'meldung', 'description' => 'Einzelansicht der KIG-Nachrichten.', 'hide' => 1],
        ];

        $pages = [];
        $sorting = 128;

        foreach ($definitions as $key => $definition) {
            $data = [
                'pid' => $rootId,
                'sorting' => $sorting,
                'tstamp' => time(),
                'title' => $definition['title'],
                'type' => 'regular',
                'alias' => $definition['alias'],
                'pageTitle' => $definition['title'].' | KIG Fürthen',
                'language' => 'de',
                'layout' => $layoutId,
                'robots' => 'index,follow',
                'description' => $definition['description'],
                'hide' => $definition['hide'] ?? 0,
                'published' => 1,
                'dateFormat' => 'd.m.Y',
                'timeFormat' => 'H:i',
                'datimFormat' => 'd.m.Y H:i',
            ];

            $pages[$key] = $this->upsert('tl_page', ['pid' => $rootId, 'alias' => $definition['alias']], $data);
            $sorting += 128;
        }

        return $pages;
    }

    private function ensureNewsArchive(int $readerPageId): int
    {
        return $this->upsert('tl_news_archive', ['title' => self::ARCHIVE_TITLE], [
            'tstamp' => time(),
            'title' => self::ARCHIVE_TITLE,
            'jumpTo' => $readerPageId,
            'notify' => 'notify_admin',
            'sortOrder' => 'descending',
            'perPage' => 10,
        ]);
    }

    private function ensureNewsReaderModule(int $themeId, int $archiveId): int
    {
        return $this->upsert('tl_module', ['name' => 'KIG-Nachrichtenleser'], [
            'pid' => $themeId,
            'tstamp' => time(),
            'name' => 'KIG-Nachrichtenleser',
            'type' => 'newsreader',
            'news_archives' => serialize([$archiveId]),
            'news_template' => 'news_full_kig',
            'news_keepCanonical' => 0,
        ]);
    }

    private function ensureNewsListModule(int $themeId, int $archiveId, int $readerModuleId, string $name, int $limit): int
    {
        return $this->upsert('tl_module', ['name' => $name], [
            'pid' => $themeId,
            'tstamp' => time(),
            'name' => $name,
            'type' => 'newslist',
            'news_archives' => serialize([$archiveId]),
            'news_readerModule' => $readerModuleId,
            'numberOfItems' => $limit,
            'news_featured' => 'all_items',
            'news_order' => 'order_date_desc',
            'news_template' => 'news_latest_kig',
            'cssID' => serialize(['', 'kig-news-grid']),
        ]);
    }

    private function ensureContactForm(): int
    {
        $formId = $this->upsert('tl_form', ['alias' => 'kig-kontakt'], [
            'tstamp' => time(),
            'title' => 'Kontaktformular KIG Fürthen',
            'alias' => 'kig-kontakt',
            'sendViaEmail' => 1,
            'storeValues' => 0,
            'recipient' => '{{page::adminEmail}}',
            'subject' => 'Kontaktanfrage über die KIG-Webseite',
            'format' => 'raw',
            'method' => 'POST',
            'confirmation' => '<p>Vielen Dank für Ihre Nachricht. Ihre Anfrage wurde übermittelt.</p>',
        ]);

        $fields = [
            ['type' => 'text', 'name' => 'name', 'label' => 'Ihr Name', 'mandatory' => 1, 'sorting' => 128],
            ['type' => 'text', 'name' => 'email', 'label' => 'Ihre E-Mail-Adresse', 'mandatory' => 1, 'rgxp' => 'email', 'sorting' => 256],
            ['type' => 'text', 'name' => 'subject', 'label' => 'Betreff', 'mandatory' => 1, 'sorting' => 384],
            ['type' => 'textarea', 'name' => 'message', 'label' => 'Ihre Nachricht', 'mandatory' => 1, 'sorting' => 512],
            ['type' => 'checkbox', 'name' => 'privacy', 'label' => 'Datenschutz', 'mandatory' => 1, 'options' => serialize([['value' => 'yes', 'label' => 'Ich habe die Datenschutzhinweise zur Kenntnis genommen.']]), 'sorting' => 640],
            ['type' => 'captcha', 'name' => 'captcha', 'label' => 'Spamschutz', 'mandatory' => 1, 'sorting' => 768],
            ['type' => 'submit', 'name' => 'submit', 'label' => 'Nachricht senden', 'slabel' => 'Nachricht senden', 'sorting' => 896],
        ];

        foreach ($fields as $field) {
            $name = $field['name'];
            unset($field['name']);
            $this->upsert('tl_form_field', ['pid' => $formId, 'name' => $name], array_merge([
                'pid' => $formId,
                'tstamp' => time(),
                'name' => $name,
            ], $field));
        }

        return $formId;
    }

    private function ensureArticles(array $pages, int $authorId, int $homeNewsModuleId, int $newsPageModuleId, int $readerModuleId, int $contactFormId): array
    {
        $articles = [];

        $homeArticle = $this->ensureArticle($pages['startseite'], 'Startseite', 'startseite', $authorId);
        $articles['startseite'] = $homeArticle;
        $this->ensureTextElement($homeArticle, 128, '<section class="kig-hero"><img src="/files/kig-fuerthen/panorama.jpg" alt="Panoramablick auf Fürthen"></section><section class="kig-welcome"><h1>Herzlich willkommen bei der KIG Fürthen</h1><p>Schön, dass Sie da sind! Wir freuen uns über Ihr Interesse an unserer Arbeit und laden Sie ein, sich über unsere Ziele, Projekte und aktuellen Themen zu informieren.</p><span class="kig-gold-divider"></span></section><section class="kig-news-heading"><div><p class="kig-section-label">AKTUELLES</p><h2>Neuigkeiten aus der KIG Fürthen</h2></div><a href="/aktuelles">Alle Meldungen ansehen <span aria-hidden="true">→</span></a></section>');
        $this->ensureModuleElement($homeArticle, 256, $homeNewsModuleId);

        $newsArticle = $this->ensureArticle($pages['aktuelles'], 'Aktuelles', 'aktuelles', $authorId);
        $articles['aktuelles'] = $newsArticle;
        $this->ensureTextElement($newsArticle, 128, '<section class="kig-page-intro"><p class="kig-section-label">AKTUELLES</p><h1>Neuigkeiten aus der KIG Fürthen</h1><p>Hier finden Sie aktuelle Informationen, Berichte und Nachrichten aus unserer Gemeinde.</p></section>');
        $this->ensureModuleElement($newsArticle, 256, $newsPageModuleId);

        $memberArticle = $this->ensureArticle($pages['mitglieder'], 'Mitglieder', 'mitglieder', $authorId);
        $articles['mitglieder'] = $memberArticle;
        $this->ensureTextElement($memberArticle, 128, '<section class="kig-page-content"><p class="kig-section-label">GEMEINSAM FÜR FÜRTHEN</p><h1>Die Menschen hinter der KIG</h1><p>Die Kommunale Interessen Gemeinschaft Fürthen bringt Menschen zusammen, die sich für die Entwicklung unseres Ortes einsetzen. Gemeinsam greifen wir Themen auf, sammeln Ideen und setzen uns für ein lebenswertes Fürthen ein.</p><h2>Gemeinsam gestalten</h2><p>Unsere Arbeit lebt vom Austausch, von unterschiedlichen Perspektiven und vom Engagement der Menschen vor Ort. Auf dieser Beispielseite können später die Mitglieder, Ansprechpartnerinnen und Ansprechpartner sowie ihre Aufgaben vorgestellt werden.</p><p><strong>Mitgliederdaten:</strong> Bitte ergänzen Sie hier die freigegebenen Namen und Funktionen.</p></section>');

        $joinArticle = $this->ensureArticle($pages['mitmachen'], 'Mitmachen', 'mitmachen', $authorId);
        $articles['mitmachen'] = $joinArticle;
        $this->ensureTextElement($joinArticle, 128, '<section class="kig-page-content"><p class="kig-section-label">IHRE IDEE ZÄHLT</p><h1>Mitmachen und Fürthen mitgestalten</h1><p>Sie haben eine Idee, möchten ein Projekt unterstützen oder ein Thema ansprechen, das Fürthen bewegt? Dann bringen Sie sich ein. Gute Ideen entstehen, wenn Menschen miteinander reden und gemeinsam anpacken.</p><h2>So können Sie mitmachen</h2><ul><li>Teilen Sie Ihre Vorschläge und Hinweise mit uns.</li><li>Unterstützen Sie Aktionen und Veranstaltungen.</li><li>Bringen Sie sich bei Projekten und Gesprächen ein.</li></ul><p>Nutzen Sie unser Kontaktformular. Wir freuen uns auf Ihre Nachricht.</p><p><a class="kig-button-link" href="/kontakt">Zur Kontaktseite</a></p></section>');

        $contactArticle = $this->ensureArticle($pages['kontakt'], 'Kontakt', 'kontakt', $authorId);
        $articles['kontakt'] = $contactArticle;
        $this->ensureTextElement($contactArticle, 128, '<section class="kig-page-content"><p class="kig-section-label">WIR SIND FÜR SIE DA</p><h1>Kontakt zur KIG Fürthen</h1><p>Sie haben Fragen, Anregungen oder möchten ein Anliegen mit uns teilen? Schreiben Sie uns über das Kontaktformular.</p><p>Bitte tragen Sie eine gültige E-Mail-Adresse ein, damit wir Ihnen antworten können.</p></section>');
        $this->ensureFormElement($contactArticle, 256, $contactFormId);

        $imprintArticle = $this->ensureArticle($pages['impressum'], 'Impressum', 'impressum', $authorId);
        $articles['impressum'] = $imprintArticle;
        $this->ensureTextElement($imprintArticle, 128, '<section class="kig-page-content"><h1>Impressum</h1><p><strong>Hinweis zur Fertigstellung:</strong> Diese Beispielseite ist noch nicht veröffentlichungsfertig. Bitte ersetzen Sie alle folgenden Platzhalter vor dem Livegang durch die vollständigen und rechtlich geprüften Angaben.</p><h2>Angaben gemäß § 5 DDG</h2><p>[Vollständiger Name der verantwortlichen Organisation]<br>[Vertretungsberechtigte Person(en)]<br>[Straße und Hausnummer]<br>[Postleitzahl und Ort]</p><h2>Kontakt</h2><p>Telefon: [Telefonnummer]<br>E-Mail: [offizielle Kontakt-E-Mail]</p><h2>Verantwortlich für den Inhalt</h2><p>[Name und Anschrift der inhaltlich verantwortlichen Person]</p></section>');

        $privacyArticle = $this->ensureArticle($pages['datenschutz'], 'Datenschutz', 'datenschutz', $authorId);
        $articles['datenschutz'] = $privacyArticle;
        $this->ensureTextElement($privacyArticle, 128, '<section class="kig-page-content"><h1>Datenschutzhinweise</h1><p><strong>Hinweis zur Fertigstellung:</strong> Diese Seite enthält einen Beispieltext und ist noch keine vollständige Datenschutzerklärung. Bitte ergänzen und prüfen Sie die Angaben vor dem Livegang passend zu Hosting, E-Mail-Versand, eingesetzten Diensten und Verantwortlichen.</p><h2>Verantwortliche Stelle</h2><p>[Name der verantwortlichen Organisation]<br>[Anschrift]<br>[Kontakt-E-Mail]</p><h2>Kontaktformular</h2><p>Die Angaben aus dem Kontaktformular werden zur Bearbeitung Ihrer Anfrage und zur Beantwortung Ihrer Nachricht verwendet. Die Formularwerte werden durch die Beispielkonfiguration nicht dauerhaft in der Contao-Datenbank gespeichert. Der Versand erfolgt per E-Mail, sobald die offizielle Empfängeradresse und der Mailversand im System eingerichtet sind.</p><h2>Server-Protokolle</h2><p>Bitte ergänzen Sie hier die Angaben Ihres Hosting-Anbieters zu Server-Logdateien, Speicherdauer und Rechtsgrundlage.</p><h2>Ihre Rechte</h2><p>Bitte ergänzen Sie die Informationen zu Auskunft, Berichtigung, Löschung, Einschränkung der Verarbeitung, Datenübertragbarkeit und Beschwerderecht.</p></section>');

        $readerArticle = $this->ensureArticle($pages['meldung'], 'Nachrichtenleser', 'nachrichtenleser', $authorId);
        $articles['meldung'] = $readerArticle;
        $this->ensureModuleElement($readerArticle, 128, $readerModuleId);

        return $articles;
    }

    private function ensureArticle(int $pageId, string $title, string $alias, int $authorId): int
    {
        return $this->upsert('tl_article', ['pid' => $pageId, 'alias' => $alias], [
            'pid' => $pageId,
            'sorting' => 128,
            'tstamp' => time(),
            'title' => $title,
            'alias' => $alias,
            'author' => $authorId,
            'inColumn' => 'main',
            'published' => 1,
        ]);
    }

    private function ensureTextElement(int $articleId, int $sorting, string $html): void
    {
        $this->upsert('tl_content', ['ptable' => 'tl_article', 'pid' => $articleId, 'sorting' => $sorting], [
            'pid' => $articleId,
            'ptable' => 'tl_article',
            'sorting' => $sorting,
            'tstamp' => time(),
            'type' => 'text',
            'headline' => serialize(['value' => '', 'unit' => 'h2']),
            'text' => $html,
        ]);
    }

    private function ensureModuleElement(int $articleId, int $sorting, int $moduleId): void
    {
        $this->upsert('tl_content', ['ptable' => 'tl_article', 'pid' => $articleId, 'sorting' => $sorting], [
            'pid' => $articleId,
            'ptable' => 'tl_article',
            'sorting' => $sorting,
            'tstamp' => time(),
            'type' => 'module',
            'module' => $moduleId,
        ]);
    }

    private function ensureFormElement(int $articleId, int $sorting, int $formId): void
    {
        $this->upsert('tl_content', ['ptable' => 'tl_article', 'pid' => $articleId, 'sorting' => $sorting], [
            'pid' => $articleId,
            'ptable' => 'tl_article',
            'sorting' => $sorting,
            'tstamp' => time(),
            'type' => 'form',
            'form' => $formId,
        ]);
    }

    private function ensureNews(int $archiveId, int $authorId): void
    {
        $items = [
            [
                'headline' => 'Straßensanierung in der Hauptstraße',
                'alias' => 'strassensanierung-hauptstrasse',
                'date' => strtotime('2026-09-12 10:00:00'),
                'teaser' => 'Die Arbeiten beginnen voraussichtlich im Oktober. Hier finden Sie alle wichtigen Informationen.',
                'text' => '<p>Die geplante Sanierung der Hauptstraße ist ein wichtiges Thema für unseren Ort. Die Arbeiten sollen voraussichtlich im Oktober beginnen.</p><p>Bitte beachten Sie die örtlichen Hinweise und mögliche Einschränkungen während der Bauzeit. Weitere Informationen und konkrete Zeitpläne werden ergänzt, sobald sie offiziell vorliegen.</p>',
                'image' => 'meldung-1.jpg',
            ],
            [
                'headline' => 'Blühflächen für ein lebenswertes Fürthen',
                'alias' => 'bluehflaechen-fuerthen',
                'date' => strtotime('2026-09-05 10:00:00'),
                'teaser' => 'Neue Blühflächen sollen die Artenvielfalt fördern und unser Ortsbild noch schöner machen.',
                'text' => '<p>Blühflächen können Lebensräume für Insekten schaffen und unser Ortsbild aufwerten. Die Idee: geeignete Flächen naturnah gestalten und so einen Beitrag zur Artenvielfalt leisten.</p><p>Auf dieser Beispielseite können später konkrete Standorte, Beteiligungsmöglichkeiten und Projekttermine ergänzt werden.</p>',
                'image' => 'meldung-2.jpg',
            ],
            [
                'headline' => 'Gelungenes Dorffest – Danke an alle!',
                'alias' => 'gelungenes-dorffest-danke',
                'date' => strtotime('2026-08-28 10:00:00'),
                'teaser' => 'Ein tolles Fest mit vielen Besucherinnen und Besuchern. Wir sagen Danke für das große Engagement!',
                'text' => '<p>Ein schönes Dorffest lebt von den Menschen, die es besuchen, vorbereiten und unterstützen. Wir bedanken uns bei allen Helferinnen und Helfern sowie bei den Besucherinnen und Besuchern für das Engagement und die gute Stimmung.</p><p>Die Beispielmeldung kann später durch einen eigenen Rückblick mit weiteren Fotos ergänzt werden.</p>',
                'image' => 'meldung-3.jpg',
            ],
        ];

        foreach ($items as $item) {
            $file = FilesModel::findByPath('files/kig-fuerthen/'.$item['image']);
            if (null === $file) {
                throw new \RuntimeException('Die Bilddatei konnte nicht in der Contao-Dateiverwaltung registriert werden: '.$item['image']);
            }

            $newsId = $this->upsert('tl_news', ['alias' => $item['alias']], [
                'pid' => $archiveId,
                'tstamp' => time(),
                'headline' => $item['headline'],
                'alias' => $item['alias'],
                'author' => $authorId,
                'date' => $item['date'],
                'time' => strtotime('1970-01-01 10:00:00'),
                'pageTitle' => $item['headline'].' | KIG Fürthen',
                'description' => $item['teaser'],
                'subheadline' => '',
                'teaser' => '<p>'.$item['teaser'].'</p>',
                'addImage' => 1,
                'singleSRC' => $file->uuid,
                'alt' => $item['headline'],
                'floating' => 'above',
                'source' => 'default',
                'published' => 1,
            ]);

            $this->upsert('tl_content', ['ptable' => 'tl_news', 'pid' => $newsId, 'sorting' => 128], [
                'pid' => $newsId,
                'ptable' => 'tl_news',
                'sorting' => 128,
                'tstamp' => time(),
                'type' => 'text',
                'headline' => serialize(['value' => '', 'unit' => 'h2']),
                'text' => $item['text'],
            ]);
        }
    }

    private function ensureRootLayout(int $rootId, int $layoutId): void
    {
        $this->updateById('tl_page', $rootId, ['layout' => $layoutId, 'published' => 1, 'tstamp' => time()]);
    }

    private function upsert(string $table, array $criteria, array $data): int
    {
        $id = $this->findId($table, $criteria);

        if (null === $id) {
            return $this->insert($table, array_merge($criteria, $data));
        }

        $this->updateById($table, $id, $data);

        return $id;
    }

    private function findId(string $table, array $criteria): ?int
    {
        $conditions = [];
        $values = [];

        foreach ($criteria as $column => $value) {
            if (null === $value) {
                $conditions[] = $this->connection->quoteIdentifier($column).' IS NULL';
            } else {
                $conditions[] = $this->connection->quoteIdentifier($column).' = ?';
                $values[] = $value;
            }
        }

        $sql = 'SELECT '.$this->connection->quoteIdentifier('id').' FROM '.$this->connection->quoteIdentifier($table).' WHERE '.implode(' AND ', $conditions).' ORDER BY '.$this->connection->quoteIdentifier('id').' LIMIT 1';
        $id = $this->connection->fetchOne($sql, $values);

        return false === $id ? null : (int) $id;
    }

    private function insert(string $table, array $data): int
    {
        $columns = array_keys($data);
        $quotedColumns = array_map(fn (string $column): string => $this->connection->quoteIdentifier($column), $columns);
        $placeholders = implode(', ', array_fill(0, count($columns), '?'));
        $sql = 'INSERT INTO '.$this->connection->quoteIdentifier($table).' ('.implode(', ', $quotedColumns).') VALUES ('.$placeholders.')';
        $this->connection->executeStatement($sql, array_values($data));

        return (int) $this->connection->lastInsertId();
    }

    private function updateById(string $table, int $id, array $data): void
    {
        $sets = [];
        $values = [];

        foreach ($data as $column => $value) {
            $sets[] = $this->connection->quoteIdentifier($column).' = ?';
            $values[] = $value;
        }

        $values[] = $id;
        $sql = 'UPDATE '.$this->connection->quoteIdentifier($table).' SET '.implode(', ', $sets).' WHERE '.$this->connection->quoteIdentifier('id').' = ?';
        $this->connection->executeStatement($sql, $values);
    }
}
