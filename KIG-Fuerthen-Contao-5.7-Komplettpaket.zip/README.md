# KIG Fürthen – Contao 5.7 Paket

Dieses Paket enthält ein Contao-Bundle-Grundgerüst, das KIG-Fürthen-Design, Twig-Vorlagen für Contao-Nachrichtenliste und Nachrichtenleser sowie die CSS- und JavaScript-Dateien.

## Inhalt

- `composer.json`: Composer-Paketdefinition für Contao 5.7
- `src/`: Contao-Bundle und Contao-Manager-Plugin
- `contao/templates/twig/news/news_latest_kig.html.twig`: Kartenlayout für die originale Contao-Nachrichtenliste
- `contao/templates/twig/news/news_full_kig.html.twig`: Detailansicht für den originalen Contao-Nachrichtenleser
- `BACKEND-EINRICHTUNG.txt`: Einrichtungsschritte für Theme, Seiten und Nachrichtenmodule
- `public/css/` und `public/js/`: Gestaltung und Barrierefreiheitsfunktionen
- `public/images/`: Logo und Bildmaterial aus dem gelieferten Entwurf
- `preview/`: eigenständige HTML-Vorschau

## Wichtige Installationshinweise

Dieses ZIP ist der Quellcode eines Composer-Bundles. Der Contao Manager installiert Composer-Pakete aus Composer-Repositories, zum Beispiel Packagist oder einem Git-Repository. Er installiert nicht einfach ein beliebiges Quellcode-ZIP als Erweiterung.

Für die Installation als Composer-Paket muss dieses Paket in ein Git-Repository gestellt oder als lokales Composer-Path-Repository eingebunden werden. Anschließend wird `kig-fuerthen/contao-theme-bundle` über den Contao Manager als Paket hinzugefügt.

Nach der Composer-Installation müssen die öffentlichen Bundle-Dateien veröffentlicht werden. Üblicherweise geschieht dies über den Contao-Console-Befehl `assets:install public`.

## Noch erforderliche Backend-Einrichtung

Die vorhandene Contao-Installation hat noch keine Inhalte. Daher enthält dieses Paket absichtlich keinen fremden Datenbank-Dump und überschreibt keine Datenbank.

Nach der Paketinstallation sind im Contao-Backend noch anzulegen und zu verbinden:

1. Ein Nachrichtenarchiv.
2. Eine Nachrichtenliste mit diesem Archiv und dem Nachrichtentemplate `news_latest_kig`.
3. Ein Nachrichtenleser für die Detailansicht.
4. Eine Seite für Aktuelles und eine Seite für den Nachrichtenleser.
5. Die Seiten Startseite, Mitglieder, Mitmachen, Kontakt, Impressum und Datenschutz.
6. Ein Seitenlayout mit den passenden Kopf-, Haupt- und Fußzeilenbereichen.
7. Die CSS-Datei `bundles/kigfuerthen/css/kig-fuerthen.css` und JavaScript-Datei `bundles/kigfuerthen/js/kig-fuerthen.js` im Seitenlayout.

Die vollständige 1:1-Übernahme aller Backend-Datensätze als sofort startfertiges Contao-Theme benötigt zusätzlich einen von Contao erzeugten Theme-Export und einen zur Zielinstallation passenden Contao-Backup-Dump. Diese Daten sind in diesem Paket nicht erfunden.

## Kompatibilität

- Ziel: Contao 5.7
- PHP: ab 8.2
- Verwendet das originale Contao-Nachrichtensystem
- Twig-Templates, keine HTML5/PHP-Templates
- Keine Code-Kommentare in den ausgelieferten PHP-, Twig-, CSS- oder JavaScript-Dateien
